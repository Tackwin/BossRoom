#pragma once
#include "Vector2.hpp"
#include "json.hpp"

class Probe {
public:
	Probe(nlohmann::basic_json<> _json, Vector2 pos, Vector2 dest, std::function<void(Probe*)> onSetup, std::function<void(Probe*, float)> update, std::function<void(Probe*)> onDestroy);
	~Probe();

	std::function<void(Probe*, float)> _update;
	std::function<void(Probe*)> _onDestroy;
	std::function<void(Probe*)> _onSetup;

	float _a;
	Vector2 _pos;
	float _speed;
	float _radius;
	Vector2 _dest;
	sf::Color _color;
	bool _remove = false;
	bool _setuped = false;
	sf::CircleShape _shape;
	nlohmann::basic_json<> _json;

	std::vector<std::string> _keys;

	void update(float dt);
	void draw(sf::RenderTarget& target);

	void operator=(const Probe& other);
};

