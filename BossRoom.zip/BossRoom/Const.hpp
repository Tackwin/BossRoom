#pragma once
#include <string>
#include <random>
#include <memory>


class Game;
namespace C {
	constexpr char			JSON_PATH[]		= "res/config.json";
	constexpr double		PI				= 3.14159265358979323846;
	constexpr unsigned int	SEED			= 31415926;

	constexpr unsigned int	WIDTH			= 1280;
	constexpr unsigned int	HEIGHT			= 720;

	constexpr unsigned int	N_LEVEL			= 1;

	extern std::mt19937 rng;
	extern ::std::shared_ptr<Game> game;
};

