#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "Vector2.hpp"
#include "json.hpp"

class Game;
class Player {
public:
	Player() {};
	Player(std::shared_ptr<Game> world, nlohmann::basic_json<> json);
	~Player();

	int _life;
	int _maxLife;
	Vector2 _pos;
	Vector2 _dir;
	float _speed;
	float _radius;
	sf::Color _color;
	float _dashRange;
	float _sprintSpeed;
	float _invincibleTime;

	nlohmann::basic_json<> _json;

	std::shared_ptr<Game> _world;

	std::string _cdKeyAction = "";
	std::string _cdKeyActionCaC = "";

	bool _cdAction = true;
	bool _distance = true;
	bool _cdActionCaC = true;
	bool _invincible = false;
	bool _freeze = false;

	bool _evenShot = false;

	sf::CircleShape _shape;

	sf::Sound _hitSound;

	void update(float dt);
	void draw(sf::RenderTarget &target);

	void hit(int d);
	void startCaC();
};

