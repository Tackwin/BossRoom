#pragma once
#include <SFML/Graphics.hpp>
#include <fstream>
#include <vector>

#include "json.hpp"

#include "Vector2.hpp"

class Boss;
class Level;
class Probe;
class Player;
class Projectile;

class Game {
public:
	Game();
	~Game();

	nlohmann::json _json;

	Level* _level;

	Player* _player;

	sf::View _view;
	sf::View _uiView;
	Vector2 _viewPos;
	sf::Text _fpsText;
	Vector2 _viewSize;
	bool _distance = true;

	int avgN = 0;
	int avgRange = 1000;
	float avgMs = 0.f;

	sf::RectangleShape _boosLifeShape;
	sf::RectangleShape _playerLife;

	void update(float dt);
	void draw(sf::RenderTarget &target);
	
	void caCHit(int d);

	void createBosses();
};
