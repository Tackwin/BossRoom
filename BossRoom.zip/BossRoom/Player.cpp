#include "InputsManager.hpp"
#include "AssetsManager.hpp"
#include "TimerManager.hpp"
#include "Projectile.hpp"
#include "Player.hpp"
#include "Level.hpp"
#include "Const.hpp"
#include "Game.hpp"

//vraiment ? 8 PUTAIN DE CARACTERES pour un PUTAIN de namespace, 'tain......
using namespace nlohmann;
Player::Player(std::shared_ptr<Game> world, basic_json<> json) :
	_json(json),
	_world(world) {

	_life = json["LIFE"].get<int>();
	_maxLife = json["LIFE"].get<int>();
	_speed = json["SPEED"].get<float>();
	_radius = json["RADIUS"].get<float>();
	_dashRange = json["DASH"].get<float>();
	_pos.x = json["STARTPOS"]["x"].get<float>();
	_pos.y = json["STARTPOS"]["y"].get<float>();
	_sprintSpeed = json["SPRINT_SPEED"].get<float>();

	_invincibleTime = json["INVINCIBLE_TIME"].get<float>();
	_color = sf::Color(
		json["COLOR"]["R"].get<sf::Uint8>(),
		json["COLOR"]["G"].get<sf::Uint8>(),
		json["COLOR"]["B"].get<sf::Uint8>()
	);

	_shape = sf::CircleShape(_radius);
	_shape.setFillColor(_color);
	_shape.setOrigin(_radius, _radius);
	_shape.setPosition(_pos);

	_hitSound = sf::Sound(AssetsManager::getSound("hit"));

	_cdKeyAction = TimerManager::addFunction(json["CDACTION"].get<float>(), "cdAction", [&](float)->bool {
		_cdAction = true;
		return false;
	});
	_cdKeyActionCaC = TimerManager::addFunction(json["CDACTIONCAC"].get<float>(), "cdActionCaC", [&](float)->bool {
		_cdActionCaC = true;
		_world->caCHit(_json["DAMAGECAC"].get<int>());
		_shape.setFillColor(_color);
		_freeze = false;
		TimerManager::pauseFunction(_cdKeyActionCaC);
		return false;
	});
}

Player::~Player() {
	TimerManager::removeFunction(_cdKeyAction);
}

void Player::update(float dt) {
	bool tryingToShoot = _distance && InputsManager::isMousePressed(_json["ACTION_BUTTON"].get<int>());

	if(!_freeze) {
		_dir = Vector2::ZERO;
		if(InputsManager::isKeyPressed(_json["UP_KEY"].get<int>())) {
			_dir.y = -1;
		} else if(InputsManager::isKeyPressed(_json["DOWN_KEY"].get<int>())) {
			_dir.y = 1;
		}
		if(InputsManager::isKeyPressed(_json["LEFT_KEY"].get<int>())) {
			_dir.x = -1;
		} else if(InputsManager::isKeyPressed(_json["RIGHT_KEY"].get<int>())) {
			_dir.x = 1;
		}
		_dir.normalize();
		if(tryingToShoot)
			_dir *= .2f;
		_pos += _dir * (InputsManager::isKeyPressed(_json["SPEED_KEY"].get<int>()) ? _sprintSpeed : _speed) * dt;
		if(InputsManager::isKeyJustPressed(_json["DASH_KEY"].get<int>())) {
			_pos += (InputsManager::getMouseWorldPos() - _pos).normalize() * _dashRange;
		}
	}

	if(tryingToShoot && _cdAction) {
		_cdAction = false;
		TimerManager::restartFunction(_cdKeyAction);

		Vector2 dir = (InputsManager::getMouseWorldPos() - _pos).normalize();
		float a = dir.angleX();
		a += static_cast<float>((_evenShot ? -1 : 1) * C::PI / 6);
		Vector2 pos = _pos + Vector2(cos(a), sin(a)) * (_json["RADIUS"].get<float>() + 5);

		_evenShot = !_evenShot;
		auto p = Projectile(_json["PROJECTILE"], pos, dir, true);
		C::game->_level->addProjectile(p);
	} else if(!_distance && _cdActionCaC && InputsManager::isMouseJustPressed(_json["ACTION_BUTTON"].get<int>())) {
		_cdActionCaC = false;
		startCaC();
	}
}

void Player::draw(sf::RenderTarget &target) {
	_shape.setPosition(_pos);
	target.draw(_shape);
}

void Player::hit(int d) {
	_invincible = true;

	if(_hitSound.getStatus() == sf::Sound::Stopped)
		_hitSound.play();

	_life -= d;
	_shape.setFillColor(sf::Color(230, 230, 230));
	int *n = new int(0);
	TimerManager::addFunction(0.33f, "blinkDown", [&, n](float) -> bool {
		_shape.setFillColor(((*n)++ % 2 == 0) ? _color : sf::Color(230, 230, 230));
		if(*n >= 3) {
			_invincible = false;
			delete n;
			return true;
		}
		return false;
	});
}

void Player::startCaC() {
	TimerManager::restartFunction(_cdKeyActionCaC);
	_shape.setFillColor(sf::Color::Blue);
	_freeze = true;
}
