#include "AnimatedSprite.hpp"
#include "TimerManager.hpp"

AnimatedSprite::AnimatedSprite(const sf::Texture &texture, int tw, int th, float t, int n, bool loopOnce) 
	: 	sf::Sprite(texture),
		_tw(tw), _th(th), _t(t), _nFrame(n),
		_loopOnce(loopOnce) {
	setTextureRect(sf::IntRect(0, 0, tw, th));
	_keyFrameChange = TimerManager::addFunction(t, "frameChange", [&](float)->bool{
		_cFrame = (_cFrame + 1) % _nFrame;
		setTextureRect(sf::IntRect(_tw * _cFrame, 0, _tw, _th));
		return false;
	});
}
AnimatedSprite::~AnimatedSprite(){
	TimerManager::removeFunction(_keyFrameChange);
}

void AnimatedSprite::pause(){
	TimerManager::pauseFunction(_keyFrameChange);
}
void AnimatedSprite::resume(){
	TimerManager::resumeFunction(_keyFrameChange);
}
void AnimatedSprite::reset(){
	_cFrame = 0;
	setTextureRect(sf::IntRect(0, 0, _tw, _th));
}