#include <fstream>

#include "AssetsManager.hpp"
#include "InputsManager.hpp"
#include "TimerManager.hpp"
#include "Projectile.hpp"
#include "Rectangle.hpp"
#include "Patterns.hpp"
#include "Utility.hpp"
#include "Const.hpp"
#include "Clock.hpp"
#include "Game.hpp"

std::mt19937 C::rng(C::SEED);
std::shared_ptr<Game> C::game = nullptr;

int main() {
	TimerManager::INCREMENTAL = false;

	AssetsManager::loadFont("consola", "res/consola.ttf");
	printf("\n");
	AssetsManager::loadSound("shoot", "res/shoot.wav");
	AssetsManager::loadSound("hit", "res/hit.wav");

	Game game;

	sf::RenderWindow window(sf::VideoMode(C::WIDTH, C::HEIGHT), "Boss room");
	window.setFramerateLimit(0);

	sf::Clock dtClock;
	while(window.isOpen()) {
		float dt = dtClock.restart().asSeconds();
		dt = dt < 1 / 30.f ? dt : 1 / 30.f;
		InputsManager::update(window);
		TimerManager::update(dt);
		game.update(dt);
	
		window.clear();
		game.draw(window);
		window.display();
	}
	return EXIT_SUCCESS;
}