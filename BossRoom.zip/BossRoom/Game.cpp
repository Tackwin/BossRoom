#include "Game.hpp"

#include "AssetsManager.hpp"
#include "InputsManager.hpp"
#include "TimerManager.hpp"
#include "Patterns.hpp"
#include "Player.hpp"
#include "Level.hpp"
#include "Const.hpp"

using namespace nlohmann;

Game::Game() {
	C::game = std::shared_ptr<Game>(this);

	std::ifstream stream(C::JSON_PATH);
	stream >> _json;

	Boss::createBosses(_json);
	Level::createLevels();
	
	_level = Level::levels[0];

	_player = new Player(std::shared_ptr<Game>(this), _json["PLAYER"]);
	_playerLife.setOutlineColor(sf::Color(10, 10, 30));
	_playerLife.setSize({ 40, 40 });
	_playerLife.setOutlineThickness(2);

	_boosLifeShape.setPosition(20, 20);
	_boosLifeShape.setFillColor(sf::Color(140, 50, 50));
	_boosLifeShape.setOutlineColor(sf::Color(10, 30, 10));
	_boosLifeShape.setOutlineThickness(5);

	_fpsText.setFont(AssetsManager::getFont("consola"));
	_fpsText.setCharacterSize(15);
	_fpsText.setPosition(5, 5);

	_viewPos = { C::WIDTH / 2.f, C::HEIGHT / 2.f };
	_viewSize = { static_cast<float>(C::WIDTH), static_cast<float>(C::HEIGHT) };
	_uiView = sf::View(_viewPos, _viewSize);
	_view = sf::View(_viewPos, _viewSize);
}

Game::~Game() {
}


void Game::update(float dt) {
	avgMs += dt;
	if(avgN++ > avgRange) {
		_fpsText.setString("Fps: " + std::to_string(1 / (avgMs / avgRange)));
		avgN = 0;
		avgMs = 0;
	}

	_player->update(dt);
	_level->update(dt);
	

	//On switch le mode, soit au cac, soit a distance
	if(_distance && (_player->_pos - _level->_boss->_pos).length2() < (150 + _player->_radius + _level->_boss->_radius) * (150 + _player->_radius + _level->_boss->_radius)) {
		TimerManager::addSquaredIOEase<Vector2>(0.5f, "cameraTranslate", &_viewPos, _view.getCenter(), _level->_boss->_pos);
		TimerManager::addSquaredIOEase<Vector2>(0.5f, "cameraZoom", &_viewSize, _view.getSize(), {C::WIDTH / 1.5f, C::HEIGHT / 1.5f});
		_distance = false;
	} else if(!_distance && (_player->_pos - _level->_boss->_pos).length2() > (250 + _player->_radius + _level->_boss->_radius) * (250 + _player->_radius + _level->_boss->_radius)) {
		TimerManager::addSquaredIOEase<Vector2>(0.5f, "cameraTranslate", &_viewPos, _level->_boss->_pos, { C::WIDTH / 2.f, C::HEIGHT / 2.f });
		TimerManager::addSquaredIOEase<Vector2>(0.5f, "cameraZoom", &_viewSize, _view.getSize(), {C::WIDTH / 1.f, C::HEIGHT / 1.f});
		_distance = true;
	}
	_player->_distance = _distance;
}
void Game::draw(sf::RenderTarget &target) {
	auto& initView = target.getView();
	if(_viewPos != _view.getCenter())
		_view.setCenter(_viewPos);
	if(_viewSize != _view.getSize())
		_view.setSize(_viewSize);

	_player->draw(target);
	_level->render(target);
	target.setView(_uiView);

	for(int i = 0; i < _player->_maxLife; i++) {
		_playerLife.setFillColor(i < _player->_life ? sf::Color(180, 50, 50) : sf::Color(90, 20, 20));
		_playerLife.setPosition(10 + i * (_playerLife.getSize().x + 5), (C::HEIGHT - 10) - _playerLife.getSize().y);
		target.draw(_playerLife);
	}

	_boosLifeShape.setSize(Vector2({ static_cast<float>(_level->_boss->_life) * (C::WIDTH - 40) / _level->_boss->_maxLife, 50 }));
	target.draw(_boosLifeShape);

	target.draw(_fpsText);

	target.setView(_view);
	target.setView(initView);
}


void Game::createBosses() {
}

void Game::caCHit(int d) {
	Vector2 dir = (InputsManager::getMouseWorldPos() - _player->_pos).normalize();
	if(Vector2::equal(_player->_pos + dir * 100, _level->_boss->_pos, _level->_boss->_radius + _player->_radius)) {
		_level->_boss->hit(d);
	}
}