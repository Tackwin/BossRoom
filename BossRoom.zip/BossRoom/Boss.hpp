#pragma once
#include <memory>

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include "json.hpp"

#include "Rectangle.hpp"
#include "Const.hpp"
#include "Clock.hpp"

class Game;
class Boss {
public:
	Boss();
	Boss(std::shared_ptr<Game> world, nlohmann::basic_json<> json,
		 std::function<void(float, Boss&)> updateFunction, std::function<void(Boss&)> init, std::function<void(Boss&)> unInit);
	~Boss();

	nlohmann::json _json;

	int _life;
	int _maxLife;
	Vector2 _pos;
	float _radius;
	sf::Color _color;

	std::shared_ptr<Game> _world;

	sf::CircleShape _shape;

	std::vector<Rectangle> _rectBox;
	std::vector<std::string> _keyPatterns;
	std::vector<std::string> _keysRunningPatterns;

	std::function<void(Boss&)> _init;
	std::function<void(float, Boss&)> _updateFunction;
	std::function<void(Boss&)> _unInit;
	
	sf::Sound _shootSound;

	void hit(int d);

	void update(float dt);
	void draw(sf::RenderTarget& target);

	static std::vector<std::shared_ptr<Boss>> bosses;
	static void createBosses(const nlohmann::basic_json<>& json);
};

