#include "Level.hpp"

#include "Player.hpp"
#include "Const.hpp"
#include "Boss.hpp"
#include "Game.hpp"

std::vector<Level*> Level::levels(C::N_LEVEL);

void Level::createLevels() {
	levels[0] = new Level(C::game, Boss::bosses[0]);
}

Level::Level() : _player(C::game->_player) {

}

Level::Level(std::shared_ptr<Game> game, std::shared_ptr<Boss> boss)
	: _game(game), _boss(boss), _player(game->_player) {

}

Level::~Level() {
}


void Level::update(float dt) {

	_boss->update(dt);

	for(auto &p : _projectiles) {
		p.update(dt);
	}
	for(auto &p : _probes) {
		p.update(dt);
	}

	for(auto &p : _projectiles) {
		if(p._remove)
			continue;
		if(p._player && Vector2::equal(p._pos, _boss->_pos, p._radius + _boss->_radius)) {
			p._remove = true;
			_boss->hit(p._damage);
		} else if(!_player->_invincible && !p._player && Vector2::equal(p._pos, _player->_pos, p._radius + _player->_radius)) {
			p._remove = true;
			_player->hit(p._damage);
		}
	}

	for(int i = _probes.size() - 1; i >= 0; --i) {
		if(_probes[i]._remove) {
			_probes[i] = _probes.back();
			_probes.pop_back();
		}
	}
	for(int i = _projectiles.size() - 1; i >= 0; --i) {
		if(_projectiles[i]._remove) {
			_projectiles[i] = _projectiles.back();
			_projectiles.pop_back();
		}
	}
}

void Level::render(sf::RenderTarget& target) {
	_boss->draw(target);
	for (auto &p : _projectiles) {
		p.draw(target);
	}
	for (auto &p : _probes) {
		p.draw(target);
	}
}

void Level::addProjectile(const Projectile& projectile) {
	_projectiles.push_back(projectile);
}

