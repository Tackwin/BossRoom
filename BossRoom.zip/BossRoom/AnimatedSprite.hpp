#include <SFML/Graphics.hpp>

class AnimatedSprite : public sf::Sprite {
private:
	int _tw;
	int _th;

	float _t;

	int _nFrame;
	int _cFrame;

	std::string _keyFrameChange;

	bool _loopOnce = false;
public:
	AnimatedSprite(const sf::Texture &texture, int tw, int th, float t, int n, bool loopOnce = false);
	~AnimatedSprite();

	void pause();
	void resume();
	void reset();
};