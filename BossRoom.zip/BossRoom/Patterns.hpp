#pragma once
#include "TimerManager.hpp"
#include "Projectile.hpp"
#include "Rectangle.hpp"
#include "Const.hpp"
#include "Level.hpp"
#include "Boss.hpp"
#include "Game.hpp"

class Patterns {
public:

	static std::string addRandomBatch(std::shared_ptr<Boss> boss, int nBlast, int nOrbs, float a, float dtA, float time) {
		std::uniform_real_distribution<float> dist(a - dtA / 2.f, a + dtA / 2.f);

		int *n = new int(0); // Compteur combien de vague a lancer
		return TimerManager::addFunction(time / nBlast, "random batch", [boss, n, nBlast, nOrbs, a, dtA, dist](float)->bool {

			for(int i = 0; i < nOrbs; i++) {
				float ca = dist(C::rng);

				Vector2 dir = { cos(ca), sin(ca) };
				Vector2 pos = boss->_pos + dir * (boss->_radius + 10);

				C::game->_level->addProjectile(Projectile(boss->_json["PROJECTILE"], pos, dir, false));
			}
			if(++(*n) >= nBlast) { // 8 �tant le nombre de vague
				delete n;
				return true;
			}
			return false;
		});
	}
	static std::string addRadiusBlast(std::shared_ptr<Boss> boss, int nBlast, int nOrbs, float a, float dtA, float time, float speed = -1.f) {
		int *n = new int(0); // Compteur combien de vague a lancer
		return TimerManager::addFunction(time / nBlast, "radius blast", [boss, n, nBlast, nOrbs, a, dtA, speed](float)->bool {

			for(int i = 0; i < nOrbs; i++) {
				float ca = a - dtA / 2 + i * dtA / (nOrbs - 1);

				//La c'est pour alterner un petit dtA permettant de fill les gaps
				ca += ((*n % 2 == 0) ? 1 : -1) * dtA / ((nOrbs - 1) * 4);

				Vector2 dir = { cos(ca), sin(ca) };
				Vector2 pos = boss->_pos + dir * (boss->_radius + 10);

				auto p = Projectile(boss->_json["PROJECTILE"], pos, dir, false);
				p._speed = speed < 0 ? p._speed : speed;
				C::game->_level->addProjectile(p);
			}
			if(++(*n) >= nBlast) { // 8 �tant le nombre de vague
				delete n;
				return true;
			}
			return false;
		});
	};
	static std::string addSlashes(std::shared_ptr<Boss> boss, int nBlast, int nOrbs, float a, float dtA, float time, float speed = -1) {
		int *m = new int(0);
		return TimerManager::addFunction(time / nBlast, "slashes", [time, boss, m, nBlast, nOrbs, a, dtA, speed](float)->bool {
			for(int i = 0; i < nOrbs; i++) {
				float ca = a + (*m % 2 == 0 ? -1 : 1) * (-dtA / 2 + i * dtA / (nOrbs - 1));
				Vector2 dir = { cos(ca), sin(ca) };
				Vector2 pos = boss->_pos + dir * (boss->_radius + 10);

				TimerManager::addFunction( i * (time / nBlast) / (nOrbs + 5), "shot", [boss, pos, dir, speed](float)->bool {
					auto p = Projectile(boss->_json["PROJECTILE"], pos, dir, false);
					p._speed = speed < 0 ? p._speed : speed;
					C::game->_level->addProjectile(p);
					return true;
				});
			}

			if(++(*m) >= nBlast) {
				delete m;
				return true;
			}
			return false;
		});
	}
	static std::string addDirectiveFire(std::shared_ptr<Boss> boss, int nBlasts, int nOrbs, Vector2 p, float a, int dtW, float t) {
		int *n = new int(0);
		return TimerManager::addFunction(t / nBlasts, "directive fire", [t, nBlasts, nOrbs, p, a, dtW, boss, n](float)->bool {
			for(int i = 0; i < nOrbs; i++) {
				Vector2 cp = {	p.x + cosf(a + static_cast<float>(C::PI) / 2) * (static_cast<float>(i) / static_cast<float>(nOrbs - 1) * dtW - dtW / 2), 
								p.y + sinf(a + static_cast<float>(C::PI) / 2) * (static_cast<float>(i) / static_cast<float>(nOrbs - 1) * dtW - dtW / 2) };
				C::game->_level->addProjectile(Projectile(boss->_json["PROJECTILE"], cp, Vector2::createUnitVector(a), false));
			}
			if(++(*n) >= nBlasts) {
				delete n;
				return true;
			}
			return false;
		});
	}
	static std::string addFrontAttack(std::shared_ptr<Boss> boss, int nAttack, float a, float w, float h, float t) {
		int *n = new int(0);
		return TimerManager::addFunction(t / nAttack, "", [n, a, w, t, nAttack, boss, h](float)->bool {
			float* dW = new float(0);
			boss->_rectBox.push_back(Rectangle(boss->_pos + Vector2::createUnitVector(a) * (boss->_radius + 2), { 1, h }, a));
			Rectangle* hitBox = &(*(boss->_rectBox.end() - 1));

			TimerManager::addSquaredIOEase(2 * (t / nAttack) / 3, "", dW, 1.f, w);
			std::string* str = new std::string(
			TimerManager::addFunction(0.f, "", [w, h, dW, boss, t, nAttack, a, hitBox](float)->bool{
				Vector2 p = boss->_pos + Vector2::createUnitVector(a) * *dW;
				hitBox->setWidth(*dW);
				return false;
			}));
			TimerManager::addFunction(t / nAttack, "", [boss, hitBox, str](float)->bool {
				auto it = std::find(boss->_rectBox.begin(), boss->_rectBox.end(), *hitBox);
				if(it != boss->_rectBox.end())
					boss->_rectBox.erase(it);
				TimerManager::removeFunction(*str);
				delete str;
				return true;
			});


			if(++(*n) >= nAttack) {
				delete n;
				return true;
			}
			return false;
		});
	}
};
