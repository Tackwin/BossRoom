#include "TimerManager.hpp"
#include "Projectile.hpp"
#include <SFML/Graphics.hpp>

using namespace nlohmann;

Projectile::Projectile() {
}
Projectile::Projectile(const Projectile& other) {
	*this = other;
}
Projectile::Projectile(basic_json<> json, Vector2 pos, Vector2 dir, bool player) :
	_pos(pos),
	_dir(dir),
	_player(player) {
	
	_dir.normalize();

	_speed = json["SPEED"].get<float>();
	_damage = json["DAMAGE"].get<int>();
	_radius = json["RADIUS"].get<float>();
	_lifespan = json["LIFESPAN"].get<float>();
	_color = sf::Color(
		json["COLOR"]["R"].get<sf::Uint8>(),
		json["COLOR"]["G"].get<sf::Uint8>(),
		json["COLOR"]["B"].get<sf::Uint8>()
	);

	_shape = sf::CircleShape(_radius);
	_shape.setFillColor(_color);
	_shape.setOrigin(_radius, _radius);
	_shape.setPosition(_pos);

	_key = TimerManager::addFunction(_lifespan, "destroy", [&](float)->bool {
		_remove = true;
		return true;
	});
}

Projectile::~Projectile() {
	if (TimerManager::functionsExist(_key))
		TimerManager::removeFunction(_key);
}

void Projectile::update(float dt) {
	_pos += _dir * _speed * dt;
}

void Projectile::draw(sf::RenderTarget &target) {
	_shape.setPosition(_pos);
	target.draw(_shape);
}

void Projectile::operator=(const Projectile & other) {
	_lifespan = other._lifespan;
	_player = other._player;
	_damage = other._damage;
	_radius = other._radius;
	_speed = other._speed;
	_color = other._color;
	_shape = other._shape;
	_pos = other._pos;
	_dir = other._dir;

	_remove = false;

	_key = TimerManager::addFunction(_lifespan, "destroy", [&](float)->bool {
		_remove = true;
		return true;
	});
}
