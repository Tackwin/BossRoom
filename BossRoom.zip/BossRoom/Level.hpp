#pragma once
#include <array>

#include "Const.hpp"
#include "Probe.hpp"
#include "Projectile.hpp"

class Game;
class Boss;
class Player;

class Level {
public:

	std::shared_ptr<Game> _game;

	std::shared_ptr<Boss> _boss;
	Player*& _player;

	std::vector<Probe> _probes;
	std::vector<Projectile> _projectiles;

	Level();
	Level(std::shared_ptr<Game> game, std::shared_ptr<Boss> boss);
	~Level();

	void update(float dt);
	void render(sf::RenderTarget& target);

	void addProjectile(const Projectile& projectile);

	static std::vector<Level*> levels;
	static void createLevels();
};

