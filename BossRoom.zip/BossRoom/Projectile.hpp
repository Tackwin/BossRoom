#pragma once
#include <SFML/Graphics.hpp>
#include "Vector2.hpp"
#include "json.hpp"

class Projectile {
public:
	Projectile();
	Projectile(const Projectile& other);
	Projectile(nlohmann::basic_json<> json, Vector2 pos, Vector2 dir, bool player);
	~Projectile();

public:
	std::string _key;

	Vector2 _pos;
	Vector2 _dir;

	float _lifespan;
	float _speed;
	float _radius;
	int _damage;
	sf::Color _color;

	bool _player;

	bool _remove = false;

	sf::CircleShape _shape;

	void update(float dt);
	void draw(sf::RenderTarget &target);

	void operator=(const Projectile& other);
};

