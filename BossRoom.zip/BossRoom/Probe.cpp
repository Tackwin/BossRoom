#include "Probe.hpp"
#include "TimerManager.hpp"

using namespace nlohmann;

Probe::Probe(basic_json<> json, Vector2 pos, Vector2 dest, std::function<void(Probe*)> onSetup, std::function<void(Probe*, float)> update, std::function<void(Probe*)> onDestroy) :
	_json(json), _pos(pos), _dest(dest), _onSetup(onSetup), _update(update), _onDestroy(onDestroy), _a(0.f) {

	_speed = json["SPEED"].get<float>();
	_radius = json["RADIUS"].get<float>();
	_color = sf::Color(
		json["COLOR"]["R"].get<sf::Uint8>(),
		json["COLOR"]["G"].get<sf::Uint8>(),
		json["COLOR"]["B"].get<sf::Uint8>()
	);

	_shape = sf::CircleShape(_radius);
	_shape.setOrigin(_radius, _radius);
	_shape.setFillColor(_color);
}

Probe::~Probe() {
	_onDestroy(this);

	for(auto &k : _keys) {
		TimerManager::removeFunction(k);
	}
}

void Probe::update(float dt) {
	if(_setuped) {
		_update(this, dt);
		return;
	}

	auto d = _dest - _pos;
	d.normalize();

	_pos += d * _speed * dt;
	if(Vector2::equal(_pos, _dest)) {
		_pos = _dest;
		_setuped = true;
		_onSetup(this);
	}
}

void Probe::draw(sf::RenderTarget& target) {
	_shape.setPosition(_pos);
	target.draw(_shape);
}

void Probe::operator=(const Probe& other) {
	_json = other._json;
	_pos = other._pos;
	_dest = other._dest;
	_onSetup = other._onSetup;
	_update = other._update; 
	_onDestroy = other._onDestroy; 
	_a = 0;

	_speed = other._speed;
	_radius = other._radius;
	_color = other._color;

	_shape = other._shape;
}
