#include "Boss.hpp"

#include "AssetsManager.hpp"
#include "TimerManager.hpp"
#include "Patterns.hpp"
#include "Player.hpp"

using namespace nlohmann;

std::vector<std::shared_ptr<Boss>> Boss::bosses(C::N_LEVEL);

void Boss::createBosses(const nlohmann::basic_json<>& json) {
	bosses[0] = std::make_shared<Boss>(C::game, json["BOSS"],
		[](float, Boss&) { //Update function
	},
		[](Boss& boss) { // Init function
		boss._keyPatterns.push_back(TimerManager::addFunction(5.f, "loop p1", [&](float)->bool {
			return false;
			if (C::game->_distance) {
				Patterns::addRadiusBlast(std::shared_ptr<Boss>(&boss), 5, 20, 0, static_cast<float>(2 * std::_Pi), 1.75f, 500);
			}
		}));
		TimerManager::addFunction(0.5f, "wait", [&](float)->bool {
			return true;
			std::string key = TimerManager::addFunction(5.f, "loop p2", [&](float)->bool {
				if (C::game->_distance && boss._life < 0.5f * boss._maxLife)
					Patterns::addSlashes(std::shared_ptr<Boss>(&boss), 3, 20, static_cast<float>(std::_Pi), static_cast<float>(std::_Pi / 4.f), 2.5f, 600);
				return false;
			});
			boss._keyPatterns.push_back(key);
		});
		boss._keyPatterns.push_back(TimerManager::addFunction(5.f, "loop p3", [&](float)->bool {
			return false;
			if (!C::game->_distance)
				Patterns::addFrontAttack(std::shared_ptr<Boss>(&boss), 2, boss._pos.angleTo(C::game->_player->_pos), 30, 50, 0.5f);
		}));
		TimerManager::addFunction(2.f, "wait", [&](float)->bool {
			return true;
			TimerManager::restartFunction(boss._keyPatterns[0]);
			TimerManager::restartFunction(boss._keyPatterns[1]);
			TimerManager::restartFunction(boss._keyPatterns[2]);
		});
	},
		[](Boss&) { // UnInit function
	}
	);
}


Boss::Boss() {

}

Boss::Boss(std::shared_ptr<Game> world, basic_json<> json,
		   std::function<void(float, Boss&)> updateFunction, std::function<void(Boss&)> init, std::function<void(Boss&)> unInit)
:	_json(json),
	_world(world),
	_updateFunction(updateFunction),
	_init(init),
	_unInit(unInit) {

	_life = json["LIFE"].get<int>();
	_maxLife = json["LIFE"].get<int>();
	_pos.x = json["STARTPOS"]["x"].get<float>();
	_pos.y = json["STARTPOS"]["y"].get<float>();
	_radius = json["RADIUS"].get<float>();
	_color = sf::Color(
		json["COLOR"]["R"].get<sf::Uint8>(),
		json["COLOR"]["G"].get<sf::Uint8>(),
		json["COLOR"]["B"].get<sf::Uint8>()
	);

	_shape = sf::CircleShape(_radius);
	_shape.setFillColor(_color);
	_shape.setOrigin(_radius, _radius);
	_shape.setPosition(_pos);

	_shootSound = sf::Sound(AssetsManager::getSound("shoot"));

	_init(*this);
}

Boss::~Boss() {
	_unInit(*this);
	for(auto &k : _keyPatterns) {
		TimerManager::removeFunction(k);
	}
}

void Boss::update(float dt) {
	_updateFunction(dt, *this);
}

void Boss::draw(sf::RenderTarget &target) {
	_shape.setPosition(_pos);
	target.draw(_shape);
	for(auto &h : _rectBox) {
		h.draw(target, sf::Color::White);
	}
}

void Boss::hit(int d) {
	_life -= d;
	_shape.setFillColor(sf::Color(230, 230, 230));
	TimerManager::addFunction(0.05f, "blinkDown", [&](float)->bool {
		_shape.setFillColor(_color);
		return true;
	});
}

